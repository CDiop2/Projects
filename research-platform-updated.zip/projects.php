<?php
require 'includes/auth.php';
redirect_if_not_logged_in();
require 'includes/header.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $title = sanitize($_POST['title']);
    $description = sanitize($_POST['description']);
    
    try {
        $pdo->beginTransaction();
        
        // Create project
        $stmt = $pdo->prepare("INSERT INTO projects (title, description, owner_id) VALUES (?, ?, ?)");
        $stmt->execute([$title, $description, $_SESSION['user_id']]);
        $projectId = $pdo->lastInsertId();
        
        // Add owner as member
        $stmt = $pdo->prepare("INSERT INTO project_members (project_id, user_id) VALUES (?, ?)");
        $stmt->execute([$projectId, $_SESSION['user_id']]);
        
        $pdo->commit();
        $_SESSION['success'] = "Project created successfully!";
        header("Location: project-view.php?id=$projectId");
        exit();
    } catch (PDOException $e) {
        $pdo->rollBack();
        $error = "Error creating project: " . $e->getMessage();
    }
}

$stmt = $pdo->prepare("SELECT * FROM projects WHERE owner_id = ?");
$stmt->execute([$_SESSION['user_id']]);
$myProjects = $stmt->fetchAll();

$stmt = $pdo->prepare("SELECT p.* FROM projects p 
                      JOIN project_members pm ON p.id = pm.project_id 
                      WHERE pm.user_id = ? AND p.owner_id != ?");
$stmt->execute([$_SESSION['user_id'], $_SESSION['user_id']]);
$sharedProjects = $stmt->fetchAll();
?>

<h2>Research Projects</h2>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<div class="card mb-4">
    <div class="card-header bg-primary text-white">
        <h4>Create New Project</h4>
    </div>
    <div class="card-body">
        <form method="POST">
            <div class="mb-3">
                <label class="form-label">Project Title</label>
                <input type="text" name="title" class="form-control" required>
            </div>
            <div class="mb-3">
                <label class="form-label">Description</label>
                <textarea name="description" class="form-control" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Create Project</button>
        </form>
    </div>
</div>

<div class="row">
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h4>My Projects</h4>
            </div>
            <div class="card-body">
                <?php if (count($myProjects) > 0): ?>
                    <div class="list-group">
                        <?php foreach ($myProjects as $project): ?>
                            <a href="project-view.php?id=<?= $project['id'] ?>" 
                               class="list-group-item list-group-item-action">
                                <h5><?= $project['title'] ?></h5>
                                <p><?= substr($project['description'], 0, 100) ?>...</p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>You haven't created any projects yet</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-6">
        <div class="card">
            <div class="card-header">
                <h4>Shared Projects</h4>
            </div>
            <div class="card-body">
                <?php if (count($sharedProjects) > 0): ?>
                    <div class="list-group">
                        <?php foreach ($sharedProjects as $project): ?>
                            <a href="project-view.php?id=<?= $project['id'] ?>" 
                               class="list-group-item list-group-item-action">
                                <h5><?= $project['title'] ?></h5>
                                <p><?= substr($project['description'], 0, 100) ?>...</p>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>No shared projects</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
require 'includes/footer.php';
?>