<?php
require 'includes/auth.php';
redirect_if_not_logged_in();
require 'includes/header.php';
?>

<h2>Dashboard</h2>
<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header">
                <h4>My Projects</h4>
            </div>
            <div class="card-body">
                <?php
                $stmt = $pdo->prepare("SELECT p.* FROM projects p 
                                      JOIN project_members pm ON p.id = pm.project_id 
                                      WHERE pm.user_id = ?");
                $stmt->execute([$_SESSION['user_id']]);
                $projects = $stmt->fetchAll();
                
                if (count($projects) > 0): ?>
                    <div class="list-group">
                        <?php foreach ($projects as $project): ?>
                            <a href="project-view.php?id=<?= $project['id'] ?>" 
                               class="list-group-item list-group-item-action">
                                <h5><?= $project['title'] ?></h5>
                                <p><?= substr($project['description'], 0, 100) ?>...</p>
                                <small>Created: <?= date('M d, Y', strtotime($project['created_at'])) ?></small>
                            </a>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>You don't have any projects yet. <a href="projects.php">Create one now</a></p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h4>Recent Documents</h4>
            </div>
            <div class="card-body">
                <?php
                $stmt = $pdo->prepare("SELECT d.*, p.title AS project_name 
                                      FROM documents d
                                      JOIN projects p ON d.project_id = p.id
                                      WHERE d.user_id = ?
                                      ORDER BY d.uploaded_at DESC LIMIT 5");
                $stmt->execute([$_SESSION['user_id']]);
                $documents = $stmt->fetchAll();
                
                if (count($documents) > 0): ?>
                    <ul class="list-group">
                        <?php foreach ($documents as $doc): ?>
                            <li class="list-group-item">
                                <a href="uploads/<?= $doc['filepath'] ?>" download>
                                    <?= $doc['filename'] ?>
                                </a>
                                <br>
                                <small>Project: <?= $doc['project_name'] ?></small>
                            </li>
                        <?php endforeach; ?>
                    </ul>
                <?php else: ?>
                    <p>No documents uploaded yet</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
</div>

<?php
require 'includes/footer.php';
?>