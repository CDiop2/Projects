<?php
require 'includes/auth.php';
redirect_if_not_logged_in();
require 'includes/header.php';

if (!isset($_GET['id'])) {
    header('Location: projects.php');
    exit();
}

$projectId = $_GET['id'];

// Check if user has access to the project
$stmt = $pdo->prepare("SELECT p.*, u.name AS owner_name 
                      FROM projects p
                      JOIN users u ON p.owner_id = u.id
                      WHERE p.id = ? AND p.id IN (
                          SELECT project_id FROM project_members WHERE user_id = ?
                      )");
$stmt->execute([$projectId, $_SESSION['user_id']]);
$project = $stmt->fetch();

if (!$project) {
    die("Access denied or project not found");
}

// Get project members
$stmt = $pdo->prepare("SELECT u.id, u.name, u.email 
                      FROM project_members pm
                      JOIN users u ON pm.user_id = u.id
                      WHERE pm.project_id = ?");
$stmt->execute([$projectId]);
$members = $stmt->fetchAll();

// Get project documents
$stmt = $pdo->prepare("SELECT d.*, u.name AS uploader_name 
                      FROM documents d
                      JOIN users u ON d.user_id = u.id
                      WHERE d.project_id = ?
                      ORDER BY d.uploaded_at DESC");
$stmt->execute([$projectId]);
$documents = $stmt->fetchAll();

// Add member form processing
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_member'])) {
    $email = sanitize($_POST['email']);
    
    $stmt = $pdo->prepare("SELECT id FROM users WHERE email = ?");
    $stmt->execute([$email]);
    $user = $stmt->fetch();
    
    if ($user) {
        try {
            $stmt = $pdo->prepare("INSERT INTO project_members (project_id, user_id) VALUES (?, ?)");
            $stmt->execute([$projectId, $user['id']]);
            $_SESSION['success'] = "Member added successfully";
            header("Location: project-view.php?id=$projectId");
            exit();
        } catch (PDOException $e) {
            $error = "User is already a member of this project";
        }
    } else {
        $error = "User not found";
    }
}
?>

<div class="d-flex justify-content-between align-items-center mb-4">
    <h2><?= $project['title'] ?></h2>
    <?php if ($project['owner_id'] == $_SESSION['user_id']): ?>
        <a href="document-upload.php?project=<?= $projectId ?>" class="btn btn-primary">
            Upload Document
        </a>
    <?php endif; ?>
</div>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<div class="row">
    <div class="col-md-8">
        <div class="card mb-4">
            <div class="card-header">
                <h4>Project Description</h4>
            </div>
            <div class="card-body">
                <p><?= nl2br($project['description']) ?></p>
                <p><strong>Owner:</strong> <?= $project['owner_name'] ?></p>
                <p><strong>Created:</strong> <?= date('M d, Y', strtotime($project['created_at'])) ?></p>
            </div>
        </div>

        <div class="card">
            <div class="card-header">
                <h4>Documents</h4>
            </div>
            <div class="card-body">
                <?php if (count($documents) > 0): ?>
                    <div class="list-group">
                        <?php foreach ($documents as $doc): ?>
                            <div class="list-group-item">
                                <div class="d-flex justify-content-between">
                                    <div>
                                        <h5><?= $doc['filename'] ?></h5>
                                        <small>Uploaded by: <?= $doc['uploader_name'] ?> on 
                                            <?= date('M d, Y h:i A', strtotime($doc['uploaded_at'])) ?>
                                        </small>
                                    </div>
                                    <div>
                                        <a href="uploads/<?= $doc['filepath'] ?>" 
                                           download="<?= $doc['filename'] ?>" 
                                           class="btn btn-sm btn-success">
                                            Download
                                        </a>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; ?>
                    </div>
                <?php else: ?>
                    <p>No documents uploaded yet</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <div class="col-md-4">
        <div class="card mb-4">
            <div class="card-header">
                <h4>Project Members</h4>
            </div>
            <div class="card-body">
                <ul class="list-group">
                    <?php foreach ($members as $member): ?>
                        <li class="list-group-item">
                            <?= $member['name'] ?>
                            <span class="text-muted">(<?= $member['email'] ?>)</span>
                        </li>
                    <?php endforeach; ?>
                </ul>
            </div>
        </div>

        <?php if ($project['owner_id'] == $_SESSION['user_id']): ?>
            <div class="card">
                <div class="card-header">
                    <h4>Add Member</h4>
                </div>
                <div class="card-body">
                    <form method="POST">
                        <div class="mb-3">
                            <label class="form-label">User Email</label>
                            <input type="email" name="email" class="form-control" required>
                        </div>
                        <button type="submit" name="add_member" class="btn btn-primary">Add to Project</button>
                    </form>
                </div>
            </div>
        <?php endif; ?>
    </div>
</div>

<?php
require 'includes/footer.php';
?>