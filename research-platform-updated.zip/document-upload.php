<?php
require 'includes/auth.php';
redirect_if_not_logged_in();
require 'includes/header.php';

if (!isset($_GET['project'])) {
    header('Location: projects.php');
    exit();
}

$projectId = $_GET['project'];

// Verify user is owner of the project
$stmt = $pdo->prepare("SELECT id FROM projects WHERE id = ? AND owner_id = ?");
$stmt->execute([$projectId, $_SESSION['user_id']]);
$project = $stmt->fetch();

if (!$project) {
    die("Project not found or you don't have permission to upload documents");
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $file = $_FILES['document'];
    
    // Validate file
    $allowedTypes = ['application/pdf', 'application/msword', 
                    'application/vnd.openxmlformats-officedocument.wordprocessingml.document',
                    'text/plain'];
    $maxSize = 5 * 1024 * 1024; // 5MB
    
    if ($file['error'] !== UPLOAD_ERR_OK) {
        $error = "File upload error";
    } elseif (!in_array($file['type'], $allowedTypes)) {
        $error = "Invalid file type. Only PDF, DOC, DOCX, TXT allowed";
    } elseif ($file['size'] > $maxSize) {
        $error = "File too large. Max 5MB allowed";
    } else {
        // Generate unique filename
        $filename = uniqid() . '_' . basename($file['name']);
        $targetPath = "uploads/" . $filename;
        
        if (move_uploaded_file($file['tmp_name'], $targetPath)) {
            try {
                $stmt = $pdo->prepare("INSERT INTO documents (project_id, user_id, filename, filepath) 
                                      VALUES (?, ?, ?, ?)");
                $stmt->execute([
                    $projectId,
                    $_SESSION['user_id'],
                    $file['name'],
                    $filename
                ]);
                $_SESSION['success'] = "Document uploaded successfully";
                header("Location: project-view.php?id=$projectId");
                exit();
            } catch (PDOException $e) {
                $error = "Database error: " . $e->getMessage();
            }
        } else {
            $error = "Failed to move uploaded file";
        }
    }
}
?>

<h2>Upload Document</h2>
<p>Project: <?= $projectId ?></p>

<?php if (isset($error)): ?>
    <div class="alert alert-danger"><?= $error ?></div>
<?php endif; ?>

<form method="POST" enctype="multipart/form-data">
    <div class="mb-3">
        <label class="form-label">Select Document</label>
        <input type="file" name="document" class="form-control" required>
        <div class="form-text">Allowed types: PDF, DOC, DOCX, TXT (Max 5MB)</div>
    </div>
    <button type="submit" class="btn btn-primary">Upload Document</button>
    <a href="project-view.php?id=<?= $projectId ?>" class="btn btn-secondary">Cancel</a>
</form>

<?php
require 'includes/footer.php';
?>