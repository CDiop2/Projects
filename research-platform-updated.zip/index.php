<?php
require 'includes/header.php';
?> 
      <h1 class="text-center">Academic Research Collaboration Platform</h1>
      <div class="row mt-5">
        <div class="col-md-6">
          <div class="card">
            <div class="card-body">
              <h2>Collaborate with Researchers</h2>
              <p>
                Join projects, share documents, and manage research activities
                in one platform.
              </p>
              <a href="register.php" class="btn btn-primary">Get Started</a>
            </div>
          </div>
        </div>
        <div class="col-md-6">
          <img
            src="https://via.placeholder.com/600x300?text=Research+Collaboration"
            alt="Research Collaboration"
            class="img-fluid rounded"
          />
        </div>
      </div> 
  
<?php
require 'includes/footer.php';
?>
